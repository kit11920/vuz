/*
Простая программа на языке Си
*/

#include <stdio.h>

#define GREETING "Hello, world!"

int main(void)
{
    puts(GREETING);

    return 0;
}

