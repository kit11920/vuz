#include <stdio.h>

int main(void)
{
    int a = 1;

    {
        a += 5;

        double a = 2.0;

        a += 0.5;

        printf("inner block, a = %f\n", a);
    }

    printf("outer block, a = %d\n", a);

    return 0;
}