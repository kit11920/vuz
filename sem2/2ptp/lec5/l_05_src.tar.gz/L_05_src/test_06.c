#include <stdio.h>

int main(void)
{
    int a = 10;
    int b = 20;
    int *pi = &a;

    printf("The beginnig\n");
    
    ++*pi;
    printf("next statment\n");

    printf("a = %d, b = %d\n", a, b);

    return 0;
}

