#include <stdio.h>
#include <stddef.h>

void print(const int *a, size_t n)
{
    printf("Array:\n");
    for (size_t i = 0; i <= n; i++)
        printf("%d ", a[i]);
    printf("\n");
}

int main(void)
{
    int a[] = {1, 2, 3, 4, 5};

    print(a, sizeof(a) / sizeof(a[0]));

    return 0;
}

