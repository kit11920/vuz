#include <stdio.h>
#include <stdlib.h>

int* ups(void)
{
    return NULL;
}

void moo(int a)
{
    int *t = ups();

    printf("%d %d\n", a, *t);
}

void boo(int a)
{
    moo(a);
}

void foo(int a)
{
    boo(a);
}

int main(void)
{
    int a = 10;

    foo(a);

    return 0;
}

