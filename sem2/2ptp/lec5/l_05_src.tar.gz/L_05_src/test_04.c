#include <stdio.h>

double circular_area(double r)
{
    const double pi = 3.1415926536;

    return pi * r * r;
}

int main(void)
{
    double area;

    area = circular_area(1.0);
    printf("%f\n", area);

    area = circular_area(5.0);
    printf("%f\n", area);

    return 0;
}
