int main(void)
{
     int i = 1;
     int a[] = {1, 2, 3};

     (void) i;
     (void) a;

     return 0;
}
