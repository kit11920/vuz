#!/bin/bash

../../../../.local/bin/CodeChecker parse --export html --output ./reports_html ./reports

