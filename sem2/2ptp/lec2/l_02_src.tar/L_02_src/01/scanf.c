#include <stdio.h>

int main(void)
{
   int i;

   printf("Enter an integer.\n");
   scanf("%d", i);
   printf("Your entered integer %d.\n", i);

   return 0;
}