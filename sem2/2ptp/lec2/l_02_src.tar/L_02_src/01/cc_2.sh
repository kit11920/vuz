#!/bin/bash

../../../../.local/bin/CodeChecker parse --print-steps ./reports

